public class Main {
    public static void main(String[] args) {
        Phone phone1 = new Phone("123-456","Samsung",0.6);
        Phone phone2 = new Phone("789-234", "Nokia", 1.5);
        Phone phone3 = new Phone("987-654", "Siemens", 0.8);

        System.out.println("Phone1 Number: " + phone1.getNumber() + " , Model: " + phone1.getModel() + " , Weight: " + phone1.getWeight());
        System.out.println("Phone2 Number: " + phone2.getNumber() + " , Model: " + phone2.getModel() + " , Weight: " + phone2.getWeight());
        System.out.println("Phone3 Number: " + phone3.getNumber() + " , Model: " + phone3.getModel() + " , Weight: " + phone3.getWeight());


        phone1.receiveCall("Mother");
        phone2.receiveCall("Father");
        phone3.receiveCall("Brother");


    }
}



/*2.Класс Phone.
Создайте класс Phone, который содержит переменные number, model и weight.
Создайте три экземпляра этого класса.
Выведите на консоль значения их переменных.
Добавить в класс Phone методы: receiveCall, имеет один параметр – имя звонящего.
Выводит на консоль сообщение “Звонит {name}”. Метод getNumber – возвращает номер телефона.
Вызвать эти методы для каждого из объектов.*/